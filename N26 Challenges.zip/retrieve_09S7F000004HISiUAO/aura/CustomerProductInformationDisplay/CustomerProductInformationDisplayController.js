({
    doInit: function(component, event, helper) {
        helper.fetchCustomerProductInformation(component, event, helper);
    }
})