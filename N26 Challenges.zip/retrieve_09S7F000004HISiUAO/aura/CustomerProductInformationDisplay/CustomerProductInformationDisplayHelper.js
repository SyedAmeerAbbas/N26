({
	//Helper function to get Customer's Product Information based on the Customer's(Contact) Product and Home Country.
	//This information will be fetched for related contact of a given Case 
    fetchCustomerProductInformation: function(component, event, helper) {
        var action = component.get('c.getRelatedContactFields');
        var recIdValue = component.get("v.recordId");
        action.setParams({
            "recordId": recIdValue
        });
        action.setCallback(this, function(a) {
            var state = a.getState(); // get the response state
            if (state == 'SUCCESS') {
                component.set('v.relatedContactFields', a.getReturnValue());
                var action2 = component.get('c.getProductInfoFromMetadataTypes');
                if (component.get('v.relatedContactFields') != null) {
                    var productName = component.get('v.relatedContactFields').Product__c;
                    var countryName = component.get('v.relatedContactFields').Home_Country__c;
                }

                action2.setParams({
                    "ProductName": productName,
                    "CountryName": countryName
                });
                action2.setCallback(this, function(a) {
                    var state = a.getState(); // get the response state
                    if (state == 'SUCCESS') {
                        component.set('v.sObjList', a.getReturnValue());
                    }
                });
                $A.enqueueAction(action2);
            }
        });
        $A.enqueueAction(action);
    }
})