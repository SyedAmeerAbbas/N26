The zipped package contains the salesforce components created for N26 challenge 1 and 2. 

1- For challenge 1 of sending survey to the customers.

	a)- For setting the Language to 'en' if any other language (except German(de) and English(en)) is selected by the customer, there is a workflow that will update the language field to English(en).

	b)- The two different language email structure is configured inside Email Templates
		
		Contact_Survey_Template_in_German
		Contact_Survey_Template_in_English
	
2-  For challenge 2 please refer lightning components under aura directory. Also, CustomerProductInformationController.cls is a related Apex controller class.

	
